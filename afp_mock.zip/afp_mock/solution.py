class InMemoryDB:
    def __init__(self):
        # TODO: your storage here
        pass

    # ---- Level 1 ----
    def set(self, key: str, field: str, value: str) -> None:
        """Set field=value in record `key` (create the record if missing)."""
        pass

    def get(self, key: str, field: str):
        """Return the value, or None if the key or field does not exist."""
        pass

    def delete(self, key: str, field: str) -> bool:
        """Delete the field. Return True if it existed and was deleted, else False."""
        pass

    # ---- Level 2+ : add methods as you unlock each level (see LEVELn.md) ----
