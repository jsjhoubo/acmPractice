class Bank:
    def __init__(self):
        # TODO: your storage here
        pass

    # ---- Level 1 ----
    def create_account(self, timestamp: int, account_id: str) -> bool:
        """Create account. False if it already exists."""
        pass

    def deposit(self, timestamp: int, account_id: str, amount: int):
        """Add amount; return new balance, or None if account missing."""
        pass

    def transfer(self, timestamp: int, source: str, target: str, amount: int):
        """Move amount source->target. Return source's new balance.
        None if: either account missing, source==target, or insufficient funds."""
        pass

    # ---- Level 2+ : add methods as you unlock each level ----
